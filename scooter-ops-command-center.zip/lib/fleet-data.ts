// Mock data for ScooterOps. Structured so real API responses (e.g. from a
// telemetry service or optimizer endpoint) can be swapped in without
// changing component contracts.

export type ZoneId =
  | "loop"
  | "river-north"
  | "west-loop"
  | "wicker-park"
  | "logan-square"
  | "lincoln-park"
  | "south-loop"
  | "hyde-park"
  | "pilsen"
  | "uptown"

export interface Zone {
  id: ZoneId
  name: string
  /** Position on the stylized map, 0-100 percentage coordinates */
  x: number
  y: number
  /** Current scooter count in this zone */
  count: number
  /** Demand pressure, -1 (oversupplied) to 1 (undersupplied / high pressure) */
  pressure: number
  radius: number
}

export interface RebalanceMove {
  id: string
  from: ZoneId
  to: ZoneId
  scooterCount: number
  distanceKm: number
}

export interface TraceStep {
  id: string
  label: string
  detail: string
  status: "complete" | "active" | "pending"
  timestamp: string
}

export const zones: Zone[] = [
  { id: "uptown", name: "Uptown", x: 58, y: 8, count: 14, pressure: -0.35, radius: 16 },
  { id: "lincoln-park", name: "Lincoln Park", x: 52, y: 24, count: 22, pressure: -0.5, radius: 18 },
  { id: "logan-square", name: "Logan Square", x: 22, y: 26, count: 9, pressure: 0.72, radius: 15 },
  { id: "wicker-park", name: "Wicker Park", x: 30, y: 38, count: 11, pressure: 0.61, radius: 16 },
  { id: "river-north", name: "River North", x: 55, y: 42, count: 41, pressure: -0.68, radius: 22 },
  { id: "west-loop", name: "West Loop", x: 38, y: 52, count: 17, pressure: 0.28, radius: 17 },
  { id: "loop", name: "The Loop", x: 58, y: 56, count: 36, pressure: -0.42, radius: 21 },
  { id: "south-loop", name: "South Loop", x: 56, y: 70, count: 13, pressure: 0.55, radius: 16 },
  { id: "pilsen", name: "Pilsen", x: 36, y: 76, count: 8, pressure: 0.8, radius: 15 },
  { id: "hyde-park", name: "Hyde Park", x: 62, y: 90, count: 10, pressure: 0.44, radius: 15 },
]

export const proposedMoves: RebalanceMove[] = [
  { id: "mv-1", from: "river-north", to: "logan-square", scooterCount: 14, distanceKm: 5.2 },
  { id: "mv-2", from: "loop", to: "pilsen", scooterCount: 12, distanceKm: 4.6 },
  { id: "mv-3", from: "lincoln-park", to: "wicker-park", scooterCount: 10, distanceKm: 3.9 },
  { id: "mv-4", from: "river-north", to: "west-loop", scooterCount: 8, distanceKm: 3.1 },
  { id: "mv-5", from: "loop", to: "hyde-park", scooterCount: 6, distanceKm: 8.7 },
]

export const traceSteps: TraceStep[] = [
  {
    id: "scan",
    label: "Live Fleet Scanned",
    detail: "312 units polled across 10 zones",
    status: "complete",
    timestamp: "04:12:01",
  },
  {
    id: "forecast",
    label: "Demand Forecast Run",
    detail: "18-hr horizon, weather + event adjusted",
    status: "complete",
    timestamp: "04:12:04",
  },
  {
    id: "optimize",
    label: "Optimizer Solved",
    detail: "MILP solver, 5 routes, 0.82s convergence",
    status: "complete",
    timestamp: "04:12:06",
  },
  {
    id: "validate",
    label: "Plan Validated",
    detail: "Battery, geofence, and labor constraints passed",
    status: "complete",
    timestamp: "04:12:07",
  },
]

export const summaryMetrics = {
  scootersMoved: 50,
  centroidScooterKm: 304.5,
  pressureImprovementPct: 7.95,
}

export const zoneById = new Map(zones.map((z) => [z.id, z]))
