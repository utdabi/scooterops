"use client"

import { useState } from "react"
import { AppHeader } from "@/components/app-header"
import { MapPanel } from "@/components/map-panel"
import { AgentTracePanel } from "@/components/agent-trace-panel"
import { RebalanceStrip } from "@/components/rebalance-strip"

export default function Page() {
  const [mode, setMode] = useState<"before" | "proposed">("proposed")

  return (
    <div className="dark flex h-screen w-full flex-col overflow-hidden bg-[#08090b] text-zinc-100">
      <AppHeader />

      <div className="flex min-h-0 flex-1">
        <div className="min-w-0 flex-[7]">
          <MapPanel mode={mode} onModeChange={setMode} />
        </div>
        <div className="w-[320px] shrink-0">
          <AgentTracePanel />
        </div>
      </div>

      <div className="h-16 shrink-0">
        <RebalanceStrip />
      </div>
    </div>
  )
}
