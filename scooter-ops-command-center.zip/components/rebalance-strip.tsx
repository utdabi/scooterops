import { ArrowRight, Gauge, MoveRight, Route } from "lucide-react"
import { proposedMoves, summaryMetrics, zoneById } from "@/lib/fleet-data"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"

function Metric({
  icon: Icon,
  label,
  value,
  suffix,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  suffix?: string
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex size-9 shrink-0 items-center justify-center rounded-md border border-white/10 bg-white/[0.03]">
        <Icon className="size-4 text-cyan-400" />
      </div>
      <div>
        <p className="text-[10px] uppercase tracking-wider text-zinc-500">{label}</p>
        <p className="text-sm font-semibold tabular-nums text-zinc-100">
          {value}
          {suffix && <span className="ml-1 text-xs font-normal text-zinc-500">{suffix}</span>}
        </p>
      </div>
    </div>
  )
}

export function RebalanceStrip() {
  return (
    <div className="flex h-full items-center gap-6 overflow-x-auto border-t border-white/10 bg-[#0b0d10] px-4">
      <div className="flex shrink-0 items-center gap-6">
        <Metric icon={MoveRight} label="Scooters Moved" value={String(summaryMetrics.scootersMoved)} />
        <Metric icon={Route} label="Centroid Scooter-KM" value={summaryMetrics.centroidScooterKm.toFixed(1)} />
        <Metric
          icon={Gauge}
          label="Pressure Improvement"
          value={summaryMetrics.pressureImprovementPct.toFixed(2)}
          suffix="%"
        />
      </div>

      <Separator orientation="vertical" className="h-8 shrink-0 bg-white/10" />

      <div className="flex min-w-0 flex-1 items-center gap-2 overflow-x-auto">
        {proposedMoves.map((move) => {
          const from = zoneById.get(move.from)
          const to = zoneById.get(move.to)
          if (!from || !to) return null
          return (
            <div
              key={move.id}
              className="flex shrink-0 items-center gap-1.5 rounded-md border border-white/10 bg-white/[0.02] px-2.5 py-1.5 text-xs"
            >
              <span className="font-medium text-zinc-300">{from.name}</span>
              <ArrowRight className="size-3 text-cyan-400" />
              <span className="font-medium text-zinc-300">{to.name}</span>
              <span className="ml-1 rounded-full bg-cyan-500/10 px-1.5 py-0.5 font-mono text-[10px] text-cyan-300">
                {move.scooterCount}
              </span>
            </div>
          )
        })}
      </div>

      <Button size="sm" className="shrink-0 bg-cyan-500 text-black hover:bg-cyan-400">
        Dispatch Fleet
      </Button>
    </div>
  )
}
