import { CheckCircle2, CircleDashed, Loader2, ShieldCheck } from "lucide-react"
import { traceSteps } from "@/lib/fleet-data"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

function StepIcon({ status }: { status: "complete" | "active" | "pending" }) {
  if (status === "complete") return <CheckCircle2 className="size-4 text-emerald-400" />
  if (status === "active") return <Loader2 className="size-4 animate-spin text-cyan-400" />
  return <CircleDashed className="size-4 text-zinc-600" />
}

export function AgentTracePanel() {
  return (
    <div className="flex h-full flex-col border-l border-white/10 bg-[#0b0d10]">
      <div className="border-b border-white/10 px-4 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Autonomous Rebalance Agent</h2>
          <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-400">
            <span className="size-1.5 rounded-full bg-emerald-400" />
            RUNNING
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <ol className="relative space-y-0">
          {traceSteps.map((step, i) => (
            <li key={step.id} className="relative flex gap-3 pb-6 last:pb-0">
              {i < traceSteps.length - 1 && (
                <span className="absolute left-[7px] top-5 h-full w-px bg-white/10" aria-hidden="true" />
              )}
              <div className="mt-0.5 shrink-0">
                <StepIcon status={step.status} />
              </div>
              <div className="min-w-0">
                <div className="flex items-baseline justify-between gap-2">
                  <p className="text-sm font-medium text-zinc-100">{step.label}</p>
                  <span className="shrink-0 text-[10px] tabular-nums text-zinc-500">{step.timestamp}</span>
                </div>
                <p className="mt-0.5 text-xs leading-snug text-zinc-500">{step.detail}</p>
              </div>
            </li>
          ))}
        </ol>

        <Separator className="my-4 bg-white/10" />

        <div
          className={cn(
            "flex items-center gap-3 rounded-md border border-emerald-500/30 bg-emerald-500/[0.06] px-3 py-3",
          )}
        >
          <ShieldCheck className="size-5 shrink-0 text-emerald-400" />
          <div>
            <p className="text-sm font-semibold text-emerald-300">APPROVED</p>
            <p className="text-xs text-zinc-500">Plan cleared for dispatch, no manual review required</p>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10 px-4 py-3">
        <p className="text-[10px] uppercase tracking-wider text-zinc-500">Solver</p>
        <p className="mt-1 font-mono text-xs text-zinc-400">chicago-fleet-optimizer-v4.2</p>
      </div>
    </div>
  )
}
