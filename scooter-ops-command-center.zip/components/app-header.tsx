import { Radar } from "lucide-react"

export function AppHeader() {
  return (
    <header className="flex h-12 shrink-0 items-center justify-between border-b border-white/10 bg-[#0b0d10] px-4">
      <div className="flex items-center gap-2.5">
        <div className="flex size-6 items-center justify-center rounded-md bg-cyan-500/15">
          <Radar className="size-3.5 text-cyan-400" />
        </div>
        <span className="text-sm font-semibold tracking-tight text-zinc-100">ScooterOps</span>
        <span className="text-xs text-zinc-500">Fleet Operations Command Center</span>
      </div>

      <div className="flex items-center gap-4 text-xs text-zinc-500">
        <span>Chicago Metro</span>
        <span className="flex items-center gap-1.5">
          <span className="size-1.5 rounded-full bg-emerald-400" />
          Live
        </span>
        <span className="font-mono tabular-nums">04:12:07 CT</span>
      </div>
    </header>
  )
}
