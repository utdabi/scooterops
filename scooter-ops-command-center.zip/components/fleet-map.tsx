"use client"

import { useMemo } from "react"
import { zones as baseZones, proposedMoves, zoneById, type Zone } from "@/lib/fleet-data"
import { cn } from "@/lib/utils"

interface FleetMapProps {
  mode: "before" | "proposed"
}

function applyMoves(zones: Zone[]) {
  const next = new Map(zones.map((z) => [z.id, { ...z }]))
  for (const move of proposedMoves) {
    const from = next.get(move.from)
    const to = next.get(move.to)
    if (from) from.count -= move.scooterCount
    if (to) to.count += move.scooterCount
  }
  // Recompute pressure as a rough function of the count delta relative to baseline
  for (const zone of next.values()) {
    const base = zoneById.get(zone.id)
    if (!base) continue
    const delta = (zone.count - base.count) / Math.max(base.count, 1)
    zone.pressure = Math.max(-1, Math.min(1, base.pressure - delta * 0.9))
  }
  return Array.from(next.values())
}

function pressureColor(pressure: number) {
  if (pressure >= 0.5) return "#ef4444" // red-500, critical high pressure
  if (pressure >= 0.15) return "#f59e0b" // amber-500, moderate pressure
  if (pressure <= -0.4) return "#0ea5e9" // sky-500, oversupplied
  return "#52525b" // zinc-600, balanced
}

function curvePath(from: Zone, to: Zone) {
  const mx = (from.x + to.x) / 2
  const my = (from.y + to.y) / 2
  // Perpendicular offset for a gentle arc
  const dx = to.x - from.x
  const dy = to.y - from.y
  const len = Math.sqrt(dx * dx + dy * dy) || 1
  const nx = -dy / len
  const ny = dx / len
  const bend = Math.min(len * 0.28, 14)
  const cx = mx + nx * bend
  const cy = my + ny * bend
  return { d: `M ${from.x} ${from.y} Q ${cx} ${cy} ${to.x} ${to.y}`, cx, cy }
}

export function FleetMap({ mode }: FleetMapProps) {
  const zones = useMemo(() => (mode === "proposed" ? applyMoves(baseZones) : baseZones), [mode])
  const zoneMap = useMemo(() => new Map(zones.map((z) => [z.id, z])), [zones])

  const streets = useMemo(
    () => [
      { x1: 0, y1: 20, x2: 100, y2: 16 },
      { x1: 0, y1: 45, x2: 100, y2: 48 },
      { x1: 0, y1: 68, x2: 100, y2: 64 },
      { x1: 20, y1: 0, x2: 26, y2: 100 },
      { x1: 46, y1: 0, x2: 50, y2: 100 },
      { x1: 68, y1: 0, x2: 64, y2: 100 },
    ],
    [],
  )

  return (
    <div className="relative h-full w-full overflow-hidden rounded-lg border border-white/10 bg-[#0a0c0f]">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
        <defs>
          <radialGradient id="pressure-red" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ef4444" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="pressure-amber" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="pressure-cyan" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#0ea5e9" stopOpacity="0.32" />
            <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0" />
          </radialGradient>
          <marker id="arrow-cyan" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#22d3ee" />
          </marker>
        </defs>

        {/* base street grid */}
        <g stroke="#ffffff" strokeOpacity="0.04" strokeWidth="0.35">
          {streets.map((s, i) => (
            <line key={i} x1={s.x1} y1={s.y1} x2={s.x2} y2={s.y2} />
          ))}
        </g>
        <rect x="0" y="0" width="100" height="100" fill="none" stroke="#ffffff" strokeOpacity="0.06" strokeWidth="0.6" />

        {/* demand pressure heatmap */}
        <g>
          {zones.map((zone) => {
            const fill = zone.pressure >= 0.5 ? "url(#pressure-red)" : zone.pressure >= 0.15 ? "url(#pressure-amber)" : zone.pressure <= -0.4 ? "url(#pressure-cyan)" : "none"
            if (fill === "none") return null
            return <circle key={zone.id} cx={zone.x} cy={zone.y} r={zone.radius * 1.6} fill={fill} />
          })}
        </g>

        {/* movement arcs, proposed mode only */}
        {mode === "proposed" && (
          <g fill="none">
            {proposedMoves.map((move, i) => {
              const from = zoneMap.get(move.from)
              const to = zoneMap.get(move.to)
              if (!from || !to) return null
              const { d } = curvePath(from, to)
              // Stagger and vary each arc's cadence so the flow reads as ambient
              // telemetry rather than synchronized motion.
              const duration = 6 + ((i * 1.7) % 4) // 6s - 10s
              const delay = (i * 1.1) % 3 // 0s - 3s
              return (
                <path
                  key={move.id}
                  d={d}
                  stroke="#22d3ee"
                  strokeWidth="0.55"
                  strokeOpacity="0.85"
                  markerEnd="url(#arrow-cyan)"
                  strokeDasharray="2.2 1.6"
                  className="fleet-dash"
                  style={{
                    animation: `dash ${duration}s ease-in-out infinite`,
                    animationDelay: `${delay}s`,
                  }}
                />
              )
            })}
          </g>
        )}

        {/* zone cluster markers */}
        <g>
          {zones.map((zone) => {
            const color = pressureColor(zone.pressure)
            return (
              <g key={zone.id}>
                <circle
                  cx={zone.x}
                  cy={zone.y}
                  r={Math.max(3.2, zone.count / 6)}
                  fill="#111318"
                  stroke={color}
                  strokeWidth="0.5"
                />
                <circle cx={zone.x} cy={zone.y} r="0.6" fill={color} />
              </g>
            )
          })}
        </g>
      </svg>

      {/* HTML overlay for crisp text labels */}
      <div className="absolute inset-0">
        {zones.map((zone) => (
          <div
            key={zone.id}
            className="absolute flex -translate-x-1/2 flex-col items-center gap-1 text-center"
            style={{ left: `${zone.x}%`, top: `calc(${zone.y}% + ${Math.max(3.2, zone.count / 6) * 1.05}%)` }}
          >
            <div
              className={cn(
                "whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[10px] font-medium leading-none tabular-nums",
                zone.pressure >= 0.5
                  ? "border-red-500/40 bg-red-500/10 text-red-300"
                  : zone.pressure >= 0.15
                    ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                    : zone.pressure <= -0.4
                      ? "border-sky-500/40 bg-sky-500/10 text-sky-300"
                      : "border-white/15 bg-white/5 text-zinc-300",
              )}
            >
              {zone.count} scooters
            </div>
            <div className="text-[9px] font-medium uppercase tracking-wider text-zinc-500">{zone.name}</div>
          </div>
        ))}

        {mode === "proposed" &&
          proposedMoves.map((move) => {
            const from = zoneMap.get(move.from)
            const to = zoneMap.get(move.to)
            if (!from || !to) return null
            const { cx, cy } = curvePath(from, to)
            return (
              <div
                key={move.id}
                className="absolute -translate-x-1/2 -translate-y-1/2 rounded-sm border border-cyan-400/40 bg-[#0a0c0f]/90 px-1 py-0.5 text-[9px] font-medium text-cyan-300 tabular-nums"
                style={{ left: `${cx}%`, top: `${cy}%` }}
              >
                +{move.scooterCount}
              </div>
            )
          })}
      </div>
    </div>
  )
}
